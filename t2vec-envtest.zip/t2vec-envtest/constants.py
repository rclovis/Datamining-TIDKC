PAD = 0
BOS = 1
EOS = 2
UNK = 3

PAD_WORD = '<blank>'
BOS_WORD = '<s>'
EOS_WORD = '</s>'
UNK_WORD = '<unk>'
