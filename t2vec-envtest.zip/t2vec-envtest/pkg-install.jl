using Pkg

Pkg.add("StatsBase")
Pkg.add("HDF5")
Pkg.add("DataStructures")
Pkg.add("NearestNeighbors")
Pkg.add("JSON")
Pkg.add("Serialization")
Pkg.add("CSV")
Pkg.add("DataFrames")
Pkg.add("Distances")
Pkg.add("IJulia")
Pkg.add("ArgParse")
